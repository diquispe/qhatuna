<?php $__env->startSection('content'); ?>
    <h1 class="text-left">Panel de Administracion</h1>
    <h2>Listado de Eventos de: <b><?php echo e($user->nombre); ?></b></h2>
    <hr>
    <p>Listado de Eventos registrados</p>

    <table class="table table-hover mb-5">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre del Evento</th>
            <th scope="col">Anfitrion</th>
            <th scope="col">Invitados</th>
            <th scope="col">Acciones</th>
        </tr>
        </thead>
        <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $user->eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('admin.eventos.row', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <th scope="row">#</th>
            <td>Vacio</td>
            <td>Vacio</td>
            <td>Vacio</td>
            <td>Vacio</td>
        <?php endif; ?>

        </tbody>
    </table>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>