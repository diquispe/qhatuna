<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="main-panel ps-container ps-theme-default ps-active-y">
            <?php echo $__env->make('layouts.navegacion', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- inicio del contenido -->
                            <div class="card ">
                                <div class="card-header card-header-success card-header-icon">
                                    <div class="card-icon">
                                        <i class="material-icons"></i>
                                    </div>
                                    <h4 class="card-title">Listado de Eventos</h4>
                                </div>
                                <div class="card-body ">
                                    <div class="row">
                                        <a href="<?php echo e(route('admin.admin_eventos_create')); ?>" class="btn btn-primary">Crear Evento</a>
                                    </div>
                                    <?php echo $__env->make('admin.eventos.filtro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-hover">
                                                    <thead>
                                                    <tr>
                                                        <th scope="col"><b>ID</b></th>
                                                        <th scope="col"><b>Nombre del Evento</b></th>
                                                        <th scope="col"><b>F. Creación</b></th>
                                                        <th scope="col"><b>F. Evento</b></th>
                                                        <th scope="col"><b>Anfitrion</b></th>
                                                        <th scope="col"><b>Estado</b></th>
                                                        <th scope="col"><b>Invitados</b></th>
                                                        <th scope="col"></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>

                                                    <?php $__empty_1 = true; $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <?php echo $__env->make('admin.eventos.row', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <th scope="row">#</th>
                                                        <td>Vacio</td>
                                                        <td>Vacio</td>
                                                        <td>Vacio</td>
                                                        <td>Vacio</td>
                                                    <?php endif; ?>

                                                    </tbody>
                                                </table>
                                            </div>

                                            <?php if(count($eventos)): ?>
                                                <hr>
                                                <div class="row">
                                                    <div class="mt-2 mx-auto">
                                                        <?php echo e($eventos->appends(Request::only(['text_evento', 'estado']))->links()); ?>

                                                    </div>
                                                </div>
                                                <hr>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- fin del contenido -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>