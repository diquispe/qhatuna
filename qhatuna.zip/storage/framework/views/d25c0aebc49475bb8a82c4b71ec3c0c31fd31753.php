<div class="row">
    <div class="col-lg-12 col-md-6 col-sm-3">

        <form action="<?php echo e(route('admin.admin_eventos_index')); ?>" method="get"
              class="form-inline float-right" id="filtrarestado">
            <div class="form-group">
                <input type="text" name="text_evento" class="form-control" placeholder="Texto a Buscar" value="<?php echo e(app('request')->input('text_evento')); ?>"
                       role="search" >
            </div>
            <div class="form-group">
                <select class="selectpicker ml-2" data-size="10"
                        data-style="btn btn-success" title="Seleccione el Estado"
                        name="estado" onChange="this.form.submit();">

                    <option value="borrador" <?php if(app('request')->input('estado')== 'borrador'): ?>  selected <?php endif; ?>>Borrador</option>
                    <option value="pendiente" <?php if(app('request')->input('estado')== 'pendiente'): ?>  selected <?php endif; ?>>Pendiente</option>
                    <option value="enproceso" <?php if(app('request')->input('estado')== 'enproceso'): ?>  selected <?php endif; ?>>En Proceso</option>
                    <option value="concluido" <?php if(app('request')->input('estado')== 'concluido'): ?>  selected <?php endif; ?>>Conluido</option>
                    <option value="anulado" <?php if(app('request')->input('estado')== 'anulado'): ?>  selected <?php endif; ?>>Anulado</option>
                </select>
            </div>

        </form>
    </div>
</div>