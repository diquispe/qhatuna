<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>

    <?php endif; ?>

    <h1 class="text-center">Mis Eventos</h1>
    <hr>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $invitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('invitaciones.show', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>NO hay Invitaciones por el momento</p>
        <?php endif; ?>
    </div>



    <?php if(count($invitaciones)): ?>
        <hr>
        <div class="row">
            <div class="mt-2 mx-auto">
                <?php echo e($invitaciones->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
        <hr>
    <?php endif; ?>



<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>