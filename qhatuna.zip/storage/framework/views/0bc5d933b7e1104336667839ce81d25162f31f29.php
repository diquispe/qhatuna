<tr>
    <th scope="row"><?php echo e($evento->id); ?></th>
    <td><a href="#"><b><?php echo e(substr($evento->nombre,0, 80)); ?></b></a></td>
    <td><small><?php echo e($evento->created_at->format('l, d M Y')); ?></small></td>
    <td><small><?php echo e($evento->fecha_evento->format('l, d M Y')); ?></small></td>
    <td><b><small><a href="<?php echo e(route('admin.admin_eventos_usuario_index', $evento->user->username )); ?>"><?php echo e($evento->user->nombre); ?></a></small></b></td>
    <td>
        <?php switch($evento->estado):
            case ('borrador'): ?>
            <span class="badge badge-info">Borrador</span>
            <?php break; ?>
            <?php case ('pendiente'): ?>
            <span class="badge badge-success">Pendiente</span>
            <?php break; ?>
            <?php case ('enproceso'): ?>
            <span class="badge badge-success">En Proceso</span>
            <?php break; ?>
            <?php case ('concluido'): ?>
            <span class="badge badge-warning">Concluido</span>
            <?php break; ?>
            <?php case ('anulado'): ?>
            <span class="badge badge-danger">Anulado</span>
            <?php break; ?>
            <?php break; ?>
        <?php endswitch; ?>
    </td>
    <td>23</td>
    <td>
        <a href="/editar"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
        <a href="/eliminar"><i class="fa fa-trash" aria-hidden="true"></i></a>
        <a href="/suspender"><i class="fa fa-clock-o" aria-hidden="true"></i></a>
        <a href="/cancelar"><i class="fa fa-times-circle" aria-hidden="true"></i></a>
    </td>
</tr>