<?php $__env->startSection('content'); ?>

    <h1 class="text-center">Registrate</h1>

    <div class="formulario">
        <form method="POST" action="<?php echo e(route('register')); ?>" class="">
            <?php echo e(csrf_field()); ?>

            <div class="form-group ">
                <label for="nombre">Ingresa tu Nombre</label>
                <input type="text" name="nombre" class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>"
                       id="nombre" placeholder="Ingresa tu nombre">
                <?php if($errors->has('nombre')): ?>
                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                                </span>
                <?php endif; ?>
            </div>

            <div class="form-group ">
                <label for="nobre">Ingresa tu Email</label>
                <input type="email" name="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="email"
                       placeholder="Ingresa tu Email">
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input id="password" type="password" name="password"
                       class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"
                       required>
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                <?php endif; ?>

            </div>

            <div class="form-group">
                <label for="password-confirm">Confirm Password</label>
                <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                       required>
            </div>

            <button type="submit" class="btn btn-primary">Registrarse</button>
        </form>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>