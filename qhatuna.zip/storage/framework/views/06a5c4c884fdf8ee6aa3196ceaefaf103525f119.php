<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>

    <?php endif; ?>

    <a href="/crear-evento" class="btn btn-warning">Crear Evento</a>
    <hr>


    <form action="/messages/create" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <div class="form-group">
                <label for="nombre">Ingresa el nombre de tu Evento</label>
                <input type="text" name="nombre" id="nombre" class="form-control <?php if($errors->has('nombre')): ?> is-invalid <?php endif; ?>" placeholder="Ingresa el nombre de tu evento">
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->get('nombre'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="invalid-feedback"><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">Selecciona una Categoria</label>
                <select class="form-control" id="exampleFormControlSelect1">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                </select>
            </div>
            <div class="form-group">
                <label for="descripcion">Ingresa una descripcion corta</label>
                <textarea name="descripcion" id="descripcion"  class="form-control <?php if($errors->has('nombre')): ?> is-invalid <?php endif; ?>" cols="30" rows="10"></textarea>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->get('descripcion'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="invalid-feedback"><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </form>



<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>