<?php return array (
  'pixelpeter/laravel5-woocommerce-api-client' => 
  array (
    'providers' => 
    array (
      0 => 'Pixelpeter\\Woocommerce\\WoocommerceServiceProvider',
    ),
    'aliases' => 
    array (
      'Woocommerce' => 'Pixelpeter\\Woocommerce\\Facades\\Woocommerce',
    ),
  ),
  'hesto/multi-auth' => 
  array (
    'providers' => 
    array (
      0 => 'Hesto\\MultiAuth\\MultiAuthServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'jgrossi/corcel' => 
  array (
    'providers' => 
    array (
      0 => 'Corcel\\Laravel\\CorcelServiceProvider',
    ),
  ),
  'jenssegers/date' => 
  array (
    'providers' => 
    array (
      0 => 'Jenssegers\\Date\\DateServiceProvider',
    ),
    'aliases' => 
    array (
      'Date' => 'Jenssegers\\Date\\Date',
    ),
  ),
);